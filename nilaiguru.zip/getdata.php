<?php
// This file I have named it getdata.php
// And you will see why
include("config.php");
//Query of facebook database

$output_string = "Hello word";

// This echo for jquery 
echo json_encode($output_string);

?>